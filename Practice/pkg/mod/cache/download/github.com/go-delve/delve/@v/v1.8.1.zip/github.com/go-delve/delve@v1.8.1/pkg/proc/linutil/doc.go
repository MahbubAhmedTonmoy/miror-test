// This package contains functions and data structures used by both the
// linux implementation of the native backend and the core backend to deal
// with structures used by the linux kernel.
package linutil
